$(function () {
	$("#accordion").accordion();
});
$("#accordion").accordion({
	heightStyle: "content"
});

$('#menu').click(function(){
	$('.navi-ls').addClass('navi-ls-show')
});
